declare module 'react-world-flags';
