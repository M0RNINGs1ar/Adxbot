{
  "builds": [
    {
      "src": "vite.config.js",
      "use": "@vercel/static"
    }
  ],
  "outputDirectory": "dist"  // Specify the dist folder as the output directory
}
